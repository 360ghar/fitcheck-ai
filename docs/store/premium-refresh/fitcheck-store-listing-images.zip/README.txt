FitCheck AI store listing images — September 2026

31 RGB JPEG images: six each for iPhone, iPad, Android phone, 7-inch tablet and 10-inch tablet, plus the Google Play feature graphic. Upload to the corresponding device group in numeric filename order after final release review.

App panels are actual Flutter widget renders with synthetic sample data, not native device captures or live AI results. Try-on shows inputs; Photoshoot shows its labelled example. Native signed-build, account, accessibility and purchase checks remain release gates. No store upload has been performed.

manifest.json contains exact dimensions and alt text. Editable sources, raw renders, gallery and provenance are in docs/store/premium-refresh/ in the repository.
